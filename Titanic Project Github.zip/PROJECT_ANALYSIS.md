# Project Analysis — Titanic Survival Prediction

This document records the analysis performed on the original project folder
(`VFSCODE/titanic`) before it was reorganized into this repository. It is the
evidence trail behind every decision made in [README.md](README.md). Nothing
here is inferred beyond what the files themselves show.

## 1. Original project tree (as found)

```
titanic/
├── 20 questions titanic visualisation.py
├── 20 questions titantic.py
├── Average Age Titanic.py
├── Average Fare regression.py
├── Average male and female age.py
├── Best survival age.py
├── Best survival age - Copy.py
├── Children Adults surivival.py
├── Children Adults surivival - Copy.py
├── Data visualistation titanic.py
├── Festival.csv                              (0 bytes, empty)
├── First class embarked.py
├── Gender survival chance.py
├── Gender survival chance - Copy.py
├── Higher Fare-Higher Survival.py
├── Higher Fare-Higher Survival - Copy.py
├── Highest and lowest fare regression.py
├── Model Decision.py
├── Most popular pclass.py
├── New folder/                                (empty directory)
├── Parch survival classification.py
├── Parch survival classification - Copy.py
├── Passenger  missing cabin number.py
├── Passengers travelling alone.py
├── RandomForest Passenger survived.py
├── RandomForest Passenger survived - Copy.py
├── Randomforest regresson Fare predictor.py
├── Sales Bootcamp.py
├── Sibling Fare Regression.py
├── Sibling Fare Regression - Copy.py
├── Total passengers survived class.py
├── Total passengers survived class - Copy.py
├── gender highest fare.py
├── gender_submission.csv
├── hypothetical question.py
├── passenger class survival.py
├── passenger class survival - Copy.py
├── test.csv
└── train.csv
```

38 files + 1 empty directory. No README, no `requirements.txt`, no
`.gitignore`, no notebooks, no saved image outputs, and no git repository
existed in the original folder.

## 2. Duplicate check

Every `<name> - Copy.py` file was diffed byte-for-byte against its
non-"Copy" counterpart using `diff -q`. All 9 pairs are **100% identical**:

| Original | Copy | Result |
|---|---|---|
| Best survival age.py | Best survival age - Copy.py | Identical |
| Children Adults surivival.py | Children Adults surivival - Copy.py | Identical |
| Gender survival chance.py | Gender survival chance - Copy.py | Identical |
| Higher Fare-Higher Survival.py | Higher Fare-Higher Survival - Copy.py | Identical |
| Parch survival classification.py | Parch survival classification - Copy.py | Identical |
| RandomForest Passenger survived.py | RandomForest Passenger survived - Copy.py | Identical |
| Sibling Fare Regression.py | Sibling Fare Regression - Copy.py | Identical |
| Total passengers survived class.py | Total passengers survived class - Copy.py | Identical |
| passenger class survival.py | passenger class survival - Copy.py | Identical |

These "Copy" files carry no unique content and are excluded from GitHub.
The non-"Copy" version of each was kept.

## 3. Full file inventory, categorization, and disposition

Legend: **KEEP** = copied into repo as-is · **DOCUMENT** = findings/role
described in README/this file but not uploaded · **EXCLUDE** = left out of
the repository entirely.

| File | What it actually does (verified by reading) | Category | Repo action |
|---|---|---|---|
| `20 questions titantic.py` | Answers a 20-question analysis worksheet on `train.csv` with `print()` output: sibling/fare relation, mean age, Pclass counts, mean fare, Parch/survival, survivor count, mean age by sex, missing-value counts, 1st-class fare range, embarked city of 1st class, survival by sex, best survival age, missing-value reasoning, `HigherFare`/`Pclass`/sex-fare/cabin-missing/alone/ticket-class-fare/child questions, plus written hypotheses before each answer and a short missing-data discussion (fill vs. drop, mean/median/mode reasoning, bias risk). Also engineers `HigherFare`, `PTravel` (`SibSp+Parch`), `TmValues` (missing values per row), `Remove or not` columns, with written justification for each. | KEEP | `src/experiments/eda/` — this is the most complete single record of the author's reasoning; central to the README experiment narrative |
| `20 questions titanic visualisation.py` | Same 20-question worksheet, but answered with `matplotlib` bar charts (`plot(kind='bar')` + `plt.show()`) instead of printed text, for ~10 of the questions. | KEEP | `src/experiments/eda/` |
| `Data visualistation titanic.py` | A shorter, separate visualization pass: sibling/fare bar chart, Pclass bar/pie charts, Parch/survival bar chart, missing-values pie chart, and an Embarked-by-first-class pie chart with city names mapped from codes (`S`/`C`/`Q` → full names). Ends with a written hypothesis (large families vs. survival) that is then tested in `hypothetical question.py`. | KEEP | `src/experiments/eda/` |
| `Model Decision.py` | Not executable analysis — a plain-comment file mapping each of the 20 questions to a modeling technique (Linear Regression / Classification / Clustering) with a one-line justification for each choice. This is the author's algorithm-selection reasoning, written before the experiments below were built. | KEEP | `src/experiments/eda/` — planning artifact, valuable context for README |
| `hypothetical question.py` | A self-contained hypothesis test: "large families have lower survival than small families or solo travellers." Computes `famsize = SibSp + Parch + 1`, groups survival rate by family size, plots it, and writes an evidence-based conclusion citing the actual computed numbers (largest family-of-4 survival ~72.4%, solo-traveller survival ~30.4%). This is the only file with a stated hypothesis **and** a conclusion checked against real output. | KEEP | `src/experiments/analysis/` |
| `Average Age Titanic.py` | Linear Regression: predicts `Age` from `PassengerId` (rows with missing `Age` dropped first). `PassengerId` has no real relationship to age — this is a documented dead-end, not a working feature. | KEEP | `src/experiments/regression/` — kept and labelled as a non-working experiment in the README table |
| `Average Fare regression.py` | Linear Regression: predicts `Fare` from `PassengerId`. Same issue as above — `PassengerId` is an arbitrary index, not a real predictor. | KEEP | `src/experiments/regression/` |
| `Average male and female age.py` | Linear Regression: predicts `Age` from `Sex` (encoded 0/1). | KEEP | `src/experiments/regression/` |
| `Highest and lowest fare regression.py` | Linear Regression: predicts `Fare` from `Age`, restricted to 1st-class passengers only; reports max/min predicted fare. | KEEP | `src/experiments/regression/` |
| `Sibling Fare Regression.py` | Linear Regression: predicts `Fare` from `SibSp`, the only regression script that uses `train_test_split` (80/20) and plots train points, test points, predictions, and a specific prediction for `SibSp=10`. | KEEP | `src/experiments/regression/` — most methodologically complete regression experiment |
| `gender highest fare.py` | Linear Regression: predicts `Fare` from `Sex`. | KEEP | `src/experiments/regression/` |
| `Best survival age.py` | GaussianNB: classifies `Survived` from `Age`, tested against fixed ages including an out-of-range value (`201`). | KEEP | `src/experiments/naive_bayes/` |
| `Children Adults surivival.py` | GaussianNB: classifies `Survived` from a derived `Child` flag (`Age < 18`). | KEEP | `src/experiments/naive_bayes/` |
| `First class embarked.py` | GaussianNB: classifies `Embarked` from `Fare`, then applies the model to 1st-class passengers only to estimate embarkation-city counts. | KEEP | `src/experiments/naive_bayes/` |
| `Gender survival chance.py` | GaussianNB: classifies `Survived` from `Sex`, tested on the two fixed categories. | KEEP | `src/experiments/naive_bayes/` |
| `Higher Fare-Higher Survival.py` | GaussianNB: classifies `Survived` from `Fare`, tested at 4 fixed fare points. | KEEP | `src/experiments/naive_bayes/` |
| `Most popular pclass.py` | GaussianNB: classifies `Pclass` from `Fare`, run over every row, then tallies predicted class counts. | KEEP | `src/experiments/naive_bayes/` |
| `Parch survival classification.py` | GaussianNB: classifies `Survived` from `Parch`, tested at 3 fixed values. | KEEP | `src/experiments/naive_bayes/` |
| `Passenger  missing cabin number.py` | GaussianNB: classifies cabin-missing (`Cabin.isnull()`) from `Pclass`, run over every row and tallied. | KEEP | `src/experiments/naive_bayes/` |
| `Passengers travelling alone.py` | GaussianNB: classifies a derived `TravelAlone` flag from `SibSp+Parch`, run over every row and tallied. | KEEP | `src/experiments/naive_bayes/` |
| `Total passengers survived class.py` | GaussianNB: classifies `Survived` from `Sex` (same feature as `Gender survival chance.py`), but run over the full dataset and tallied into total survived/not-survived counts rather than the two fixed test cases. Different purpose despite the shared feature. | KEEP | `src/experiments/naive_bayes/` |
| `passenger class survival.py` | GaussianNB: classifies `Survived` from `Pclass`, tested at the 3 class values. | KEEP | `src/experiments/naive_bayes/` |
| `RandomForest Passenger survived.py` | `RandomForestClassifier` (100 trees): classifies `Survived` from `Pclass`, tested at the 3 class values — a more complex model applied to the same single feature as the Naive Bayes version. | KEEP | `src/experiments/random_forest/` |
| `Randomforest regresson Fare predictor.py` | `RandomForestRegressor` (100 trees): predicts `Fare` from `Pclass`, tested at the 3 class values. | KEEP | `src/experiments/random_forest/` |
| `Best survival age - Copy.py` and 8 other `- Copy.py` files | Byte-identical duplicates of the files above (see §2). | EXCLUDE | Not copied — zero unique content |
| `Sales Bootcamp.py` | Loads `C:\Users\Manish\Downloads\Sales - Sales.csv` — a retail sales dataset, unrelated to Titanic or this competition. Appears to be leftover practice work from a different exercise, saved into this folder by mistake. | EXCLUDE | Not copied — out of scope for this project |
| `Festival.csv` | 0 bytes. Empty file, no relation to Titanic data. | EXCLUDE | Not copied |
| `New folder/` | Empty directory, no contents. | EXCLUDE | Not copied |
| `train.csv` | Kaggle-provided training data (891 rows, includes `Survived`). Used by **every** script above. | KEEP | `data/` — small (~60 KB), needed to run any script in the repo |
| `test.csv` | Kaggle-provided test data (418 rows, no `Survived` column). **Not read by any script in the project** — confirmed by searching every file for `test.csv`; none reference it. | KEEP (documented as unused) | `data/` — kept for completeness/reproducibility even though no current script uses it |
| `gender_submission.csv` | Kaggle's sample submission format (`PassengerId,Survived`). **Not read or generated by any script** — no script in the project writes predictions for `test.csv` to a CSV. | KEEP (documented as unused) | `data/` — this is Kaggle's provided sample, not a submission the author produced |

## 4. What could and could not be determined

Determined directly from the code:
- Three model families were used: `LinearRegression` (continuous targets:
  `Age`, `Fare`), `GaussianNB` (binary/categorical targets: `Survived`,
  `Pclass`, `Embarked`, derived flags), and `RandomForestClassifier` /
  `RandomForestRegressor` (only on `Pclass → Survived` and `Pclass → Fare`).
- Every experiment uses **exactly one input feature**. No script combines
  multiple features into a single model.
- `Model Decision.py` shows the technique for each of the 20 worksheet
  questions was chosen *before* the experiment scripts were written — it
  reads as a planning document, not a retrospective summary.
- `hypothetical question.py` is the only file with an explicit
  hypothesis-test structure (hypothesis → analysis → evidence-based
  conclusion with real numbers).

Could **not** be determined, and is not claimed anywhere in the README:
- **No accuracy, precision, recall, F1, RMSE, or cross-validation score is
  computed for any classifier or regressor in the project.** Predictions are
  printed or tallied, never scored against ground truth (except the
  train/test scatter plot in `Sibling Fare Regression.py`, which shows
  predictions visually but computes no error metric).
- **There is no single final combined model.** No script uses more than one
  feature, and no script scores or ranks the different techniques against
  each other. Consequently, this project cannot honestly claim a "best
  model was selected based on performance" — that evaluation was never
  performed in the source material.
- **No Kaggle leaderboard submission was made from this code.** No script
  reads `test.csv` or writes a `PassengerId,Survived` prediction file.
  `gender_submission.csv` is Kaggle's own sample file, not a submission
  produced by the author.
- Whether `RandomForestClassifier` was intended as an "upgrade" over the
  `GaussianNB` version of the same `Pclass → Survived` problem cannot be
  confirmed — no comparison or commentary exists between the two files.

## 5. Recommended GitHub structure (original pass)

This was the structure produced on the first organizational pass, before
the combined model and the effectiveness review in §7 below:

```
titanic-survival-prediction/
├── README.md
├── PROJECT_ANALYSIS.md
├── requirements.txt
├── .gitignore
├── data/
│   ├── train.csv
│   ├── test.csv
│   └── gender_submission.csv
└── src/
    ├── eda/
    │   ├── 20 questions titanic visualisation.py
    │   ├── 20 questions titantic.py
    │   ├── Data visualistation titanic.py
    │   └── Model Decision.py
    ├── experiments/
    │   ├── regression/        (6 files)
    │   ├── naive_bayes/       (10 files)
    │   └── random_forest/     (2 files)
    └── analysis/
        └── hypothetical question.py
```

No `notebooks/` folder — no `.ipynb` files exist in the source project. No
`images/` folder — no script saves a plot to disk (`plt.savefig` is never
called); all visualizations are interactive (`plt.show()`) and can't be
reproduced as static files without running the code.

See §7 for the structure actually shipped, which supersedes this.

## 6. Known issues / uncertainties carried into the new repo

1. **Hardcoded absolute paths.** Every script reads its CSV via a literal
   Windows path, e.g. `C:\Users\Manish\Downloads\VFSCODE\titanic\train.csv`.
   Per the preservation rule for this task, these paths were **not**
   changed. Anyone who clones this repo will need to either edit the path
   in the script they want to run, or place the repo at that exact path.
   This is called out again in the README.
2. **`test.csv` and `gender_submission.csv` are currently inert** — included
   for completeness (they're small and are the standard Kaggle competition
   files) but no code in the repo touches them.
3. Whether the Titanic "Getting Started" competition data is acceptable to
   redistribute on GitHub is a Kaggle competition-rules question, not a code
   question — worth a quick confirmation by the user before making the repo
   public, though this is a widely-mirrored open tutorial dataset.
4. Several filenames contain typos in the original project (e.g.
   `surivival`, `titantic`, `Data visualistation`, `Passenger  missing
   cabin number.py` with a double space, `Randomforest regresson Fare
   predictor.py`). These were preserved exactly, unchanged, per the
   no-modification rule.

## 7. Effectiveness review and final structure (revision)

After the first organizational pass (§1–§6), a second review compared the
existing experiment scripts against each other to select which were most
relevant to the actual prediction task — "what sorts of people were more
likely to survive" — and to build one combined, evaluated model on top of
them, without altering any original script.

### 7.1 How "effectiveness" was judged

No original script computes an accuracy, precision, or cross-validation
score (§4 above), so scripts could not be ranked by a performance number
that already existed. Instead, effectiveness was judged by:

- **Feature relevance**, measured against the feature-importance output of
  the combined model in `src/final_model.py` (trained and run on
  `train.csv`): `Sex` 0.397, `Fare` 0.182, `Age` 0.128, `Pclass` 0.125,
  `FamilySize` 0.072, `Embarked` 0.035, `SibSp` 0.032, `Parch` 0.029.
- **Model/task fit** — whether the script actually targets `Survived`
  (classification) rather than an auxiliary value like `Fare` or `Age`
  (regression), since only the former directly answers the competition
  question.
- **Methodological completeness** — whether the script states a hypothesis
  and checks it against a conclusion (only `hypothetical question.py` does
  this).

### 7.2 Scripts identified as most effective/relevant

| Rank | File | Feature | Why |
|---|---|---|---|
| 1 | `RandomForest Passenger survived.py` | `Pclass` | Only ensemble method aimed at `Survived`; best-suited algorithm type present in the project for this classification task |
| 2 | `Gender survival chance.py` | `Sex` | `Sex` is the strongest predictor of survival by a wide margin |
| 3 | `passenger class survival.py` | `Pclass` | Represents socio-economic class directly; second/third strongest predictor |
| 4 | `Higher Fare-Higher Survival.py` | `Fare` | Second-strongest predictor; correlates with `Pclass` |
| 5 | `hypothetical question.py` | `FamilySize` (engineered) | Only methodologically complete hypothesis test in the project; the feature it introduces ranks above the raw `SibSp`/`Parch` it's derived from |
| 6 | `Best survival age.py` / `Children Adults surivival.py` | `Age` | Moderately predictive; the two scripts are redundant with each other (raw age vs. child/adult flag) |

Scripts judged **not effective for survival prediction** specifically
(still preserved, still documented): the 6 Linear Regression scripts,
which predict `Age`/`Fare` rather than `Survived`, and the Naive Bayes
scripts that classify something other than `Survived` (`Embarked`,
`Pclass` from `Fare`, cabin-missing, travel-alone).

### 7.3 What changed in the repository

- Added `src/final_model.py` — a new `RandomForestClassifier` combining the
  features surfaced as relevant above (`Pclass`, `Sex`, `Age`, `Fare`,
  `SibSp`, `Parch`, `Embarked`, engineered `FamilySize`). Scores 82.1%
  validation accuracy / 81.5% 5-fold CV accuracy, and writes
  `submission/submission.csv` (Kaggle format), the project's first actual
  submission.
- Added `src/eda.py` — a new, consolidated exploratory script that
  recomputes (not just repeats) the key survival-rate breakdowns by `Sex`,
  `Pclass`, `HigherFare`, `Child`, and `FamilySize` directly from
  `train.csv`, verifiable independently of the original worksheet scripts.
- Moved (not modified) `src/eda/` → `src/experiments/eda/` and
  `src/analysis/` → `src/experiments/analysis/`, so every original
  experiment script now lives under one `src/experiments/` folder, and
  `src/` itself contains only the two main files plus that folder.
- No original script's content changed. See the file-preservation check
  the assistant ran after each reorganization step.

### 7.4 Final structure

```
titanic-survival-prediction/
├── README.md
├── PROJECT_ANALYSIS.md
├── requirements.txt
├── .gitignore
├── data/
│   ├── train.csv
│   ├── test.csv
│   └── gender_submission.csv
├── submission/
│   └── submission.csv
└── src/
    ├── eda.py                     Consolidated EDA (new)
    ├── final_model.py             Combined model (new) — 82.1% val. accuracy
    └── experiments/                All 24 original scripts, unmodified
        ├── eda/                    (4 files)
        ├── analysis/                (1 file)
        ├── regression/              (6 files)
        ├── naive_bayes/             (10 files)
        └── random_forest/           (2 files)
```
