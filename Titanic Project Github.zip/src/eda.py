"""
Consolidated exploratory data analysis for the Titanic dataset.

This summarizes, in one runnable script, the survival patterns that were
found across the individual experiments in src/experiments/ (the 20-question
worksheet, the visualizations, and the family-size hypothesis test). It does
not introduce new findings — it recomputes the same patterns directly from
train.csv so they're verifiable in one place. See README.md for the full
experimentation writeup and src/experiments/ for the original, single-feature
scripts these numbers were first explored in.
"""

import pandas as pd

DATA_DIR = "data"


def main():
    df = pd.read_csv(f"{DATA_DIR}/train.csv")

    print(f"Rows: {len(df)}, Columns: {len(df.columns)}")

    print("\nMissing values per column:")
    print(df.isnull().sum()[df.isnull().sum() > 0].to_string())

    print(f"\nOverall survival rate: {df['Survived'].mean():.1%}")

    print("\nSurvival rate by Sex:")
    print(df.groupby("Sex")["Survived"].mean().to_string())

    print("\nSurvival rate by Pclass:")
    print(df.groupby("Pclass")["Survived"].mean().to_string())

    df["HigherFare"] = df["Fare"] > df["Fare"].mean()
    print("\nSurvival rate by HigherFare (Fare above dataset mean):")
    print(df.groupby("HigherFare")["Survived"].mean().to_string())

    df["Child"] = df["Age"] < 18
    print("\nSurvival rate by Child (Age < 18) vs Adult:")
    print(df.groupby("Child")["Survived"].mean().to_string())

    df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
    print("\nSurvival rate by FamilySize:")
    print(df.groupby("FamilySize")["Survived"].mean().to_string())


if __name__ == "__main__":
    main()
