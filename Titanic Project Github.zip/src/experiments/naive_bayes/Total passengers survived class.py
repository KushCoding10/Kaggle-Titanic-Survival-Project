from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df["Sex"] = df["Sex"].map({"male":0, "female":1})
x = np.array(df["Sex"]).reshape(-1,1)
y = df["Survived"]
model = GaussianNB()
model.fit(x, y)
test=np.array(df["Sex"]).reshape(-1,1)
predictions = model.predict(test) # looks at each value of male and female and predict survival
survived = 0
notsurvived = 0
for i in range(len(predictions)):
    if predictions[i] == 1:
        survived += 1
    else:
        notsurvived += 1
print("Passengers survive", survived)
print("Passengers not survive", notsurvived)