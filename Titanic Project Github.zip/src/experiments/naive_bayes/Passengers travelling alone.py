from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df["TravelAlone"] =((df["SibSp"]+df["Parch"]) == 0)
x = np.array(df["SibSp"] + df["Parch"]).reshape(-1,1)
y = df["TravelAlone"]
model = GaussianNB()
model.fit(x, y)
test = np.array(df["SibSp"]+df["Parch"]).reshape(-1,1)
predictions = model.predict(test)
alone = 0
notalone = 0
for i in range(len(predictions)):
    if predictions[i] == 1:
        alone += 1
    else:
        notalone += 1
print("Travel alone", alone)
print("Not travel alone", notalone)