from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df = df.dropna(subset=["Age"])
df["Child"] = (df["Age"] < 18)
x = np.array(df["Child"]).reshape(-1,1)
y = df["Survived"]
model = GaussianNB()
model.fit(x, y)
test = [[1], [0]]
prediction =model.predict(test)
for i in range(len(test)):
    if test[i][0] == 1:
        group = "Child"
    else:
        group = "Adult"
    if prediction[i] == 1:
        result = "Higher chance "
    else:
        result = "Lower chance"
    print(group, result)

