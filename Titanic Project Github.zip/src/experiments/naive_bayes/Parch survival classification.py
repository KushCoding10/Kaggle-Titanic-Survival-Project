from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
x = np.array(df["Parch"]).reshape(-1,1)
y = df["Survived"]
model = GaussianNB()
model.fit(x, y)
test = [[0], [2], [4]]
prediction = model.predict(test) # go through all the parch and check survived or not 
for i in range(len(test)):
    parch = test[i][0]
    if prediction[i] == 1:
        result = "Higher chance "
    else:
        result = "Lower chance "
    print("Parch",parch,result)