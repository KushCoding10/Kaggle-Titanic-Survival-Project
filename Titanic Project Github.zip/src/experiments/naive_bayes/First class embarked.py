from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df = df.dropna(subset=["Embarked"])
df["Embarked"]=df["Embarked"].map({"S":0, "C":1, "Q":2})
firstclass = df[df["Pclass"] == 1]
x = np.array(df["Fare"]).reshape(-1,1)
y = df["Embarked"]
model = GaussianNB()
model.fit(x, y)
test = np.array(firstclass["Fare"]).reshape(-1,1)
predictions = model.predict(test)
s = 0
c= 0
q = 0
for i in range(len(predictions)):
    if predictions[i] == 0:
        s+= 1
    elif predictions[i] == 1:
        c+= 1
    else:
        q+= 1
print("S", s)
print("C", c)
print("Q", q)