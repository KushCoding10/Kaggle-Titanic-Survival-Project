import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
x=np.array(df["Fare"]).reshape(-1,1)
y=df["Pclass"]
model=GaussianNB()
model.fit(x,y) # train the model
prediction=model.predict(x) # predict class for every fare
first = 0
second = 0
third = 0
for i in range(len(prediction)): # Goed through all the Fare and check which class
    if prediction[i] == 1:
        first += 1
    elif prediction[i] == 2:
        second += 1
    else:
        third += 1
print("First Class", first)
print("Second Class", second)
print("Third Class", third)

