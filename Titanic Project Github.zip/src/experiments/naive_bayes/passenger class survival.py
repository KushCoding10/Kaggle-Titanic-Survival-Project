from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
x = np.array(df["Pclass"]).reshape(-1,1)
y = df["Survived"]
model = GaussianNB()
model.fit(x, y)
test = [[1], [2], [3]]
predictions = model.predict(test)
for i in range(len(test)):
    pclass =test[i][0]
    if predictions[i] == 1:
        result = "Higher chance "
    else:
        result = "Lower chance"
    print(pclass,result)