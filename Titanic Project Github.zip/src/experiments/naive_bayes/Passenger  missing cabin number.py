from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df["Cmiss"] = df["Cabin"].isnull()
x = np.array(df["Pclass"]).reshape(-1,1)
y = df["Cmiss"]
model = GaussianNB()
model.fit(x, y)
test = np.array(df["Pclass"]).reshape(-1,1)
predictions = model.predict(test)
miss = 0
notmiss = 0
for i in range(len(predictions)):
    if predictions[i] == 1:
        miss += 1
    else:
        notmiss += 1
print("miss cab", miss)
print("not miss cab", notmiss)