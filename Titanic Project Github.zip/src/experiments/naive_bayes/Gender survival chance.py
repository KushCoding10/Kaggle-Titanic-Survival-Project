from sklearn.naive_bayes import GaussianNB
import pandas as pd
import numpy as np
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df["Sex"]=df["Sex"].replace({"male":0, "female":1})
x = np.array(df["Sex"]).reshape(-1,1)
y = df["Survived"]
model =GaussianNB()
model.fit(x, y)
test=[[0],[1]]
prediction=model.predict(test)
for i in range(len(test)):
    if test[i][0] == 0:
        gender = "Male"
    else:
        gender = "Female"
    if prediction[i] == 1:
        result = "Higher chance"
    else:
        result = "Lower chance "
    print(gender, result)