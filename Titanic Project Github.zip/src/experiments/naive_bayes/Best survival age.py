import pandas as pd
import numpy as np
from sklearn.naive_bayes import GaussianNB
df=pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df=df.dropna(subset=["Age"])
x = np.array(df["Age"]).reshape(-1,1)
y = df["Survived"]
model = GaussianNB()
model.fit(x, y)
testage = [[5],[10],[20],[30],[45],[50],[201]]
predictions=model.predict(testage)
for i in range(len(testage)):
    age = testage[i][0]
    if predictions[i] == 1:
        result = "Higher chance "
    else:
        result = "Lower chance "
    print(age,result)