import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
x=np.array(df["PassengerId"]).reshape(-1,1)
y = df["Fare"]
model = LinearRegression()
model.fit(x, y)
predictions = model.predict(x)
averagefare = predictions.mean()
print("Average Predict Fare",averagefare)