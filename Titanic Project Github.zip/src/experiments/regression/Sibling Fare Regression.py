# Does having a sibling affect the ticket fare
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
x =np.array(df["SibSp"]).reshape(-1,1)
y= np.array(df["Fare"])
print(x)
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(
    x,y,train_size=0.8,test_size=0.2,random_state=42
    )
from sklearn.linear_model import LinearRegression
model=LinearRegression()
model.fit(x_train,y_train)
sib_10= np.array([[10]])
predictfare=model.predict(sib_10)
print(f"Predicted Fare:{predictfare[0]:.2f}")
y_test_pred=model.predict(x_test)
plt.scatter(x,y)
plt.scatter(x_test,y_test)
plt.scatter(x_test,y_test_pred,marker='x')
plt.scatter(sib_10,predictfare)
plt.xlabel("SibSp")
plt.ylabel("Fare")
plt.show()
