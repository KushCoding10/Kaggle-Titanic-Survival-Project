import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df=df.dropna(subset=["Age"])# Removes rows with missing ages
x=np.array(df["PassengerId"]).reshape(-1,1)
y=df["Age"]
model=LinearRegression()
model.fit(x,y) # train the model
prediction = model.predict(x) # Predict the age
averageage =prediction.mean()
print("Predicted Average Age",averageage)