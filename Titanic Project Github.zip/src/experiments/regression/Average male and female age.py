import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
df=pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df=df.dropna(subset=["Age"]) # remove missing age rows
df["Sex"]=df["Sex"].replace({"male":0, "female":1})
x = np.array(df["Sex"]).reshape(-1,1)
y = df["Age"]
model = LinearRegression()
model.fit(x, y)
testsex = [[0], [1]]
predictions = model.predict(testsex)
for i in range(len(testsex)):
    if testsex[i][0] == 0:
        gender = "Mal"
    else:
        gender ="Fem"
    print(gender,"Average Age", predictions[i])