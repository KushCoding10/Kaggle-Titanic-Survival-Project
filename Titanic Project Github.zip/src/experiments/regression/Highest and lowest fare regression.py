import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
firstclass =df[df["Pclass"] == 1]
firstclass =firstclass.dropna(subset=["Age"])
x =np.array(firstclass["Age"]).reshape(-1,1)
y =firstclass["Fare"]
model=LinearRegression()
model.fit(x, y)
pred = model.predict(x)
highest = max(pred)
lowest = min(pred)
print("High predicted fare",highest)
print("Lowest predicted fare", lowest)