import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
df["Sex"] = df["Sex"].map({"male":0, "female":1})
x = np.array(df["Sex"]).reshape(-1,1)
y = df["Fare"]
model = LinearRegression()
model.fit(x, y)
test=[[0],[1]]
predictions = model.predict(test)
for i in range(len(test)):
    if test[i][0] == 0:
        gender = "Male"
    else:
        gender = "Female"
    print(gender,predictions[i])