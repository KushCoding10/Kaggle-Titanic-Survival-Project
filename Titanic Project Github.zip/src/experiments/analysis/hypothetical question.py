#Propose one hypothesis, perform data analysis, present relevant visualizations, and provide evidence-based conclusions
#Hypothesis = Passengers travelling with large families have a less chance of surivival than passengers travelling
#alone or with a smaller family
# The Reason for this hypothesis is that during the distaster it would be harder for larger families to stay
#together and they could not be evacuated on time, Smaller families or passengers travelling alone could
#evacuate faster

import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
# Data Analysis
df["famsize"] = df["SibSp"] + df["Parch"] + 1
survival = df.groupby("famsize")["Survived"].mean()
print(survival)
survival.plot(kind='bar')
plt.show()

#Evidence Based Conclusion
#The results support my hypothesis a bit cause passengers travelling in large families(5+) had lower survival rates than travelling in small families(2-4)
# But passengers travelling alone also had a pretty low survival rate of 30,4 % . The highest surival rate (72,4%) was for passengers travelling in fmaily of 4
#This shows that travelling with a small family can increase the chance of survival, but travelling with a large family made evacaution more harder.
# So the evidence shows that large families had lower survival rate, but travelling alone was also not that safe
 