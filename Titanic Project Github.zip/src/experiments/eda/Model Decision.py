# 1. Does having a sibling affect the ticket fare
# Linear Regression
# want to predict the number ticket fare from if a passenger has siblings.

# 2. What is the average age in the Titanic?
# Linear Regression
# Because age is a number value that can be predicted

# 3. Which Pclass is the most popular?
# Clustering
#  It groups the passenger by class to check per group the amount

# 4. What is the average fare?
# Linear Regression
# Because fare is a number value so it can be predicted

# 5. Does traveling with a parent or child affect survival?
# Classification
# Because you want to check if a passenger survived or not

# 6. How many passengers survived?
# Classification
# cause passengers are chosen if they survived or not

# 7. What is the average male and female age?
# Clustering
# It groups the passengers in gender and finds out the average ages

# 8. Which columns have the most missing values?
# Clustering
# It groups the column with the total epr column of missing data

# 9. What was the highest and lowest fare in 1 class?
# Linear Regression
# Fare is a number value that should be predicted

# 10. Which embarked city has the most 1class passengers?
# Clustering
# It groups the passengers by city and class

# 11. Who had a higher chance of survival by gender?
# Classification
#  Because you see survived or not.

# 12. Which age has the best chance of survival?
# Classification
# Because you want to predict the survival so yes or no with age 

# 13. Which columns have less missing values?
# Clustering
# beacuse it makes groups based on values

# 14. Does a higher ticket fare mean a higher chance of survival?
# Classification
# Because you want to see yes or no survival 

# 15. Does passenger class affect survival?
# Classification
# beacause you want so see yes or no survival

# 16. Which gender had the highest average ticket fare?
# Clustering
#Group by gender and compare the average fare


# 17. How many passengers are missing a cabin number?
# Clustering
#  Group by gender with cabin or not 

# 18. How many passengers were traveling alone?
# Clustering
#  It group passenger in travel alone or not

# 19. Which ticket class had the highest average fare?
# Clustering
#it groups passengers by  class to compare fare

# 20. Did children have a higher survival rate than adults?
# Classification
#yes or no survival prediction
