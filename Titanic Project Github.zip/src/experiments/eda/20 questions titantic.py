import pandas as pd
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
#1. Does having a sibling affect the ticket fare
print(df.groupby(df["SibSp"] > 0)["Fare"].mean())
#Hypothesis= Yes having a sibling can effect the ticket fare cause when you book tickets and you book for more
#people like your sibling then you usually get discount on tickets which make the ticket fare per person cheaper
# so it think having a sbiling does affect the fare
#2. What is the average age in the titanic
print(df["Age"].mean())
# My hypothesis is that the average age should be around 30 years old cause the titanic was not really a family
#cruise and it was more a cruise for adults this is why i think that the average age is around 30 years old
#3. Which Pclass is the most popular
print(df["Pclass"].value_counts())
# My hypothesis is that 3rd class is the most popular class cause it is the cheapest so alot of people wound want 
#3rd class tickets
#4.what is the average fare 
print(df["Fare"].mean())
# The average fare should be around 50 cause the titanic was a long time age nd then cruise tickets were cheap
# and titanic was a luxury cruise that time so thats why i think that the average fare is 50
#5. Does having to travel with a parent or a child affect the surival
print(df.groupby(df["Parch"] > 0)["Survived"].mean())
# ] My hypothesis is that having somebody with you like a parent or child would increase the survival rate
#cause if you have somebody with you then you have more help to survive.
#6.How many passengers survived the titanic disaster
print(df["Survived"].sum())
#7 what is the avaerage male age and female age
print(df.groupby("Sex")["Age"].mean())
# My hypothesis is that the average male and female age should be around the 30 years old cause the cruise
#is meant for adults around that age
#8. which columns has the most missing values
print(df.isnull().sum())
# I think that the age and cabin column would have alot of missing values cause during identification
#of the passengers the age and cabin are asked and it could be that lot of cabin number were not given
# and the age identification dit not go well which lead to missing values
#9.What was the highest and lowest fare paid in 1st class
firstclass=df[df["Pclass"] == 1]#8
print("Highestfare", firstclass["Fare"].max()) # 512#9
print("Lowest fare", firstclass["Fare"].min())
#10.which embarked city has the most first class passengers
print(firstclass["Embarked"].value_counts())
print("-------------------------------")
print(firstclass)
# The city which would have the most first class passengers must be a city which is pretty wealthy which
#leads to having more first class passengers boarding from there. So the weatlhiest city would have the most
#first class passengers
#11.Would you have a higher chance or survival if you are a man or woman
print(df.groupby("Sex")["Survived"].mean())
# Women would have a higher chance of survival cause usually during that time men used to sacrifice themselves
#so women and their children could survive
#12. which age has the best chance of surival
bestage=(df.groupby("Age")["Survived"].mean().idxmax())#12
print(bestage )
# the best age for survival has to be around thr 25 cause in that age you are not old and and also not too young
# this is the best age for high chance of survival
#13. WHich columns has no or the lowest missing values
# all the columns except Embarked,Age and cabin have no missing values
#14. does having a higher ticket price mean you will have a higher hance of survival
averagefare = df["Fare"].mean()#14
# Yes i think so cause if you have a higher ticket fare you go to a higher passenger class and during the crash
# the staff will take more care of the higher class passenger. This is why i think that having higher ticket price
#means higher chance of survival
df["HigherFare"] = df["Fare"] > averagefare
print(df.groupby("HigherFare")["Survived"].mean())
#15.Does passenger class affect the chance of survival?
print(df.groupby("Pclass")["Survived"].mean())
# yes it does cause there will be more care for higher class passenger during the crash 
#16.Which gender had the highest average ticket fare?
print(df.groupby("Sex")["Fare"].mean())
#17.How many passengers are missing a cabin number?
print(df["Cabin"].isnull().sum())
#18.How many passengers were traveling alone?
alone=(df["SibSp"] + df["Parch"]) == 0
print(alone.sum())
#19.Which ticket class had the highest average fare?
print(df.groupby("Pclass")["Fare"].mean())
# FIrst class cause that is the most expensive class
#20.Did children have a higher survival rate than adults?
df["Child"] = df["Age"] < 18
print(df.groupby("Child")["Survived"].mean())
# yes children would have a higher surival rate cause children would be taken care of by their parents
#which leads to higher survival rate
# Missing Values Questions
#Which columns have missing values?
print(df.isnull().sum())
#Why might they be missing?
# for the cabin it could be cause many passengers havent gotten the cabin info or the data got lost
#and for the ages it could be cause not everybody's passengers identiifcation not go well and was not 
#added to dataset or the data got lost and for the embarked it could not have been added to the dataset
#Should you fill them or remove them?
# for the cabin it is not better to fill casue there is too much data gone. It is better to remove the column
# for age it is better to fill them because it is useful for analyis and prediction
# there are only 2 values missing so you might as well fill them
#If filling them, why choose the mean, median, or mode?
# for age you use the median cause ages van have very high values and median is less affected by too high ages
# for embarked i would use mode cause it is a category and to see which city apperead the most
#Could filling introduce bias?
#yes it can filling missing values can introduce bias cause the filled values are guesses and not real info
#due to this the results are less accurate cause they are guesses

# Adding Columns
#
df["HigherFare"] = df["Fare"] > averagefare
df["PTravel"]= df["SibSp"] + df["Parch"] # total passengers travelling with
print(df)
df["TmValues"]=df.isnull().sum(axis=1) # missing values per row
print(df)
print(df.isnull().sum(axis=1).mean())
df["Remove or not"]= df["TmValues"]>1
print(df["Remove or not"])

# Why did i create this columns
# i created the Higher fare column to see which passengers had a high fare to see if that has any influence if you have
# have paid a higher fare with the survival, cause it could be that if you paid a higher fare the staff will take
#better care of you with evacuation of the cruise for survival. This is the reason that i added a higher fare colummn.

# I created this columns or Total passengers travelling with to make it easier for analysis cause there were
#two diffrent columns parch and sibslings but if we combine them you get the total passengers the passenger has
#travelled so you dont need to look at two columns to see it. This makes it easier for analysis with survival rate

# i create the total missing values per row to make it easier for the analyser to decide if they
#want to use this row with their analysis based on the missing values

# I created a remove or not row based on the average missing values per row and to check if it higher than
#the total missing values per row to easily decide if you should use this row for analysis or not based on the 
#average.

# Remove row with highest total missing values

# Why women and children survived more than men

print(df["Pclass"].value_counts())


