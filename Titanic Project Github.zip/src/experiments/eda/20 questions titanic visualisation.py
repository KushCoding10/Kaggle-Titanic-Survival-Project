import pandas as pd
import matplotlib.pyplot as plt 
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
#1. Does having a sibling affect the ticket fare
df.groupby(df["SibSp"]>0)["Fare"].mean().plot(kind='bar')
plt.show()
#2 Which Pclass is the most popular
df["Pclass"].value_counts().plot(kind='bar')
plt.show()
#3. Does having to travel with a parent or child affect the survival
df.groupby(df["Parch"]>0)["Survived"].mean().plot(kind='bar')
plt.show()
#4. # Which column has the most missing values
df.isnull().sum().plot(kind='bar')
plt.show()
#5 #Would you have a higher chance of survival if you are a man or women 
df.groupby(df["Sex"])["Survived"].mean().plot(kind='bar')
plt.show()
# Does having a higher ticket fare mean you will have a higher chance of survival
averagefare=df["Fare"].mean()
df["HigherFare"]= df["Fare"] > averagefare
df.groupby(df["HigherFare"])["Survived"].mean().plot(kind='bar')    
plt.show()
# Does passenger class affect the chance of survival
df.groupby(df["Pclass"])["Survived"].mean().plot(kind='bar')
plt.show()
# Which gender had the highest average ticket fare
df.groupby(df["Sex"])["Fare"].mean().plot(kind='bar')
plt.show()
# Which passenger class has the highest average fare
df.groupby(df["Pclass"])["Fare"].mean().plot(kind='bar')
plt.show()
# Did children have a higher survival rate than adults
df["Child"]= df["Age"] >18
df.groupby(df["Child"])["Survived"].mean().plot(kind='bar')
plt.show()
