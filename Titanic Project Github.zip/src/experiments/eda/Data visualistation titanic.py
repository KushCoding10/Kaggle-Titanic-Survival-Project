import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
#Does having a sibling affect the ticket fare
print(df.groupby("SibSp")["Fare"].sum().plot(kind='bar'))
plt.show()
#Which Pclass is the most popular
print(df["Pclass"].value_counts().plot(kind='bar'))
plt.show()
 #Does having to travel with a parent or a child affect the surival
print(df.groupby("Parch")["Survived"].sum().plot(kind='bar'))
plt.show()
#which columns has the most missing values
print(df.isnull().sum().plot(kind='pie'))
plt.show()
#which embarked city has the most first class passengers
df["Embarked"]=df["Embarked"].replace({"S":"Southampton","C":"Cherborough","Q":"Queenstown"})
firstclass=df[df["Pclass"]==1]
print(firstclass)
print(firstclass["Embarked"].value_counts().plot(kind='pie',color=["Green","Red","Blue"]))
plt.show()

# Create one hypothetical questions and make a analysis to how will you prove it 
#Hypothesis = Passengers travelling with large families have a less chance of surivival than passengers travelling
#alone or with a smaller family
