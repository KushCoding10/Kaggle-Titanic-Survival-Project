import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
df = pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\train.csv")
x = np.array(df["Pclass"]).reshape(-1,1)
y = df["Fare"]
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(x, y)
testclass = [[1], [2], [3]]
predictions = model.predict(testclass)
print(predictions)