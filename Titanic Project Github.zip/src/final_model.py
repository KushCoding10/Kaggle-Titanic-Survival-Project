"""
Combined Titanic survival model.

Unlike every script in src/experiments/, which trains on exactly one
feature, this script combines the features explored across the project
(Pclass, Sex, Age, Fare, SibSp, Parch, Embarked) plus the FamilySize
feature engineered in src/analysis/hypothetical question.py, trains a
single RandomForestClassifier, reports a real validation accuracy and
cross-validation score, and produces an actual Kaggle submission file
from test.csv (which no other script in this project reads).
"""

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score
data= pd.read_csv("C:\\Users\\Manish\\Downloads\\VFSCODE\\titanic\\data\\train.csv")

DATA_DIR = "data"
SUBMISSION_PATH = "submission/submission.csv"

FEATURES = ["Pclass", "Sex", "Age", "Fare", "SibSp", "Parch", "Embarked", "FamilySize"]


def engineer_features(df):
    df = df.copy()
    df["Sex"] = df["Sex"].map({"male": 0, "female": 1})
    df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])
    df["Embarked"] = df["Embarked"].map({"S": 0, "C": 1, "Q": 2})
    df["Age"] = df["Age"].fillna(df["Age"].median())
    df["Fare"] = df["Fare"].fillna(df["Fare"].median())
    df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
    return df


def main():
    train_df = pd.read_csv(f"{DATA_DIR}/train.csv")
    test_df = pd.read_csv(f"{DATA_DIR}/test.csv")

    train_df = engineer_features(train_df)
    test_df = engineer_features(test_df)

    x = train_df[FEATURES]
    y = train_df["Survived"]

    x_train, x_val, y_train, y_val = train_test_split(
        x, y, test_size=0.2, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=300, max_depth=6, random_state=42)
    model.fit(x_train, y_train)

    val_predictions = model.predict(x_val)
    val_accuracy = accuracy_score(y_val, val_predictions)

    cv_scores = cross_val_score(model, x, y, cv=5)

    print(f"Validation accuracy (20% holdout): {val_accuracy:.4f}")
    print(f"5-fold cross-validation accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values(ascending=False)
    print("\nFeature importances:")
    print(importances.to_string())

    # Refit on the full training set before predicting on test.csv
    model.fit(x, y)
    test_predictions = model.predict(test_df[FEATURES])

    submission = pd.DataFrame({
        "PassengerId": test_df["PassengerId"],
        "Survived": test_predictions,
    })
    submission.to_csv(SUBMISSION_PATH, index=False)
    print(f"\nSubmission written to {SUBMISSION_PATH}")


if __name__ == "__main__":
    main()
